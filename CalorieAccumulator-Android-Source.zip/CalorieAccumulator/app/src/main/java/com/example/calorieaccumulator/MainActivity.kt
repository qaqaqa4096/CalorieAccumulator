package com.example.calorieaccumulator

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast
import android.text.InputType
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.max

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("calorie_data", MODE_PRIVATE) }
    private lateinit var hourlyInput: EditText
    private lateinit var mealInputs: List<EditText>
    private lateinit var timeInputs: List<EditText>
    private lateinit var summary: TextView
    private lateinit var startedLabel: TextView

    private val mealNames = listOf("早餐", "午餐", "晚餐")
    private val defaultTimes = listOf("08:00", "12:00", "18:00")
    private val defaultCalories = listOf(400, 700, 600)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        refreshAndRender()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
            setBackgroundColor(0xFFF4F6FA.toInt())
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("熱量累積計算器", 26, true, 0xFF111827.toInt()))
        root.addView(text("每小時累積消耗，依用餐設定自動扣除攝取熱量", 14, false, 0xFF64748B.toInt()))
        root.addView(space(18))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(panel, matchWrap())
        panel.addView(text("目前淨熱量", 14, true, 0xFF475569.toInt()))
        summary = text("0 kcal", 34, true, 0xFF0F172A.toInt())
        panel.addView(summary)
        startedLabel = text("尚未開始計算", 13, false, 0xFF64748B.toInt())
        panel.addView(startedLabel)
        panel.addView(space(12))
        val stats = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        panel.addView(stats)
        stats.tag = "stats"

        root.addView(space(18))
        root.addView(text("計算設定", 20, true, 0xFF111827.toInt()))
        root.addView(text("每小時消耗熱量（大卡）", 14, true, 0xFF334155.toInt()))
        hourlyInput = numberInput(prefs.getInt("hourly", 80).toString())
        root.addView(hourlyInput)

        root.addView(space(14))
        root.addView(text("自動扣除用餐熱量", 18, true, 0xFF111827.toInt()))
        mealInputs = mealNames.indices.map { i ->
            root.addView(text(mealNames[i] + "｜攝取熱量（大卡）", 14, true, 0xFF334155.toInt()))
            val e = numberInput(prefs.getInt("meal_cal_$i", defaultCalories[i]).toString())
            root.addView(e)
            e
        }
        timeInputs = mealNames.indices.map { i ->
            root.addView(text(mealNames[i] + "｜自動扣除時間（24 小時制）", 14, true, 0xFF334155.toInt()))
            val e = plainInput(prefs.getString("meal_time_$i", defaultTimes[i]) ?: defaultTimes[i])
            e.hint = "例如 08:00"
            root.addView(e)
            e
        }

        root.addView(space(18))
        val save = Button(this).apply { text = "儲存設定"; setOnClickListener { saveSettings() } }
        root.addView(save, matchWrap())
        val start = Button(this).apply {
            text = if (prefs.getLong("start_at", 0L) == 0L) "開始累積" else "重新開始累積"
            setOnClickListener {
                prefs.edit().putLong("start_at", System.currentTimeMillis())
                    .putInt("manual_adjust", 0).apply()
                refreshAndRender()
                Toast.makeText(this@MainActivity, "已開始累積消耗熱量", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(start, matchWrap())

        root.addView(space(10))
        root.addView(text("手動調整（大卡）", 16, true, 0xFF111827.toInt()))
        val adjust = numberInput("0")
        adjust.hint = "正數增加、負數扣除"
        root.addView(adjust)
        val apply = Button(this).apply {
            text = "套用手動調整"
            setOnClickListener {
                val value = adjust.text.toString().toIntOrNull()
                if (value == null) toast("請輸入整數") else {
                    val next = prefs.getInt("manual_adjust", 0) + value
                    prefs.edit().putInt("manual_adjust", next).apply()
                    adjust.setText("")
                    refreshAndRender()
                    toast("已調整")
                }
            }
        }
        root.addView(apply, matchWrap())
        root.addView(space(14))
        root.addView(text("計算方式：已經過的完整小時 × 每小時消耗量 − 已登記餐點攝取量 + 手動調整。App 關閉期間會依開始時間補算，不需要一直開著畫面。", 13, false, 0xFF64748B.toInt()))
    }

    private fun refreshAndRender() {
        saveMealDeductions()
        val startAt = prefs.getLong("start_at", 0L)
        val elapsedHours = if (startAt > 0L) max(0L, (System.currentTimeMillis() - startAt) / 3_600_000L) else 0L
        val burned = elapsedHours * prefs.getInt("hourly", 80)
        val eaten = prefs.getInt("eaten_total", 0)
        val manual = prefs.getInt("manual_adjust", 0)
        val net = burned - eaten + manual
        summary.text = "$net kcal"
        startedLabel.text = if (startAt == 0L) "尚未開始計算" else "已累積 $elapsedHours 小時｜更新於 ${SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())}"
        startedLabel.text = if (startAt == 0L) "尚未開始｜累積消耗 $burned kcal｜攝取 $eaten kcal" else "已累積 $elapsedHours 小時｜消耗 $burned kcal｜攝取 $eaten kcal｜手動調整 $manual kcal"
    }

    private fun saveMealDeductions() {
        val startAt = prefs.getLong("start_at", 0L)
        if (startAt == 0L) return
        val now = System.currentTimeMillis()
        val day = Calendar.getInstance().apply {
            timeInMillis = startAt
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val lastDay = Calendar.getInstance().apply { timeInMillis = now }
        val edit = prefs.edit()
        var eaten = prefs.getInt("eaten_total", 0)
        while (day.timeInMillis <= lastDay.timeInMillis) {
            val dateKey = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(day.time)
            for (i in mealNames.indices) {
                val time = prefs.getString("meal_time_$i", defaultTimes[i]) ?: defaultTimes[i]
                val parts = time.split(":")
                if (parts.size != 2) continue
                val hour = parts[0].toIntOrNull() ?: continue
                val minute = parts[1].toIntOrNull() ?: continue
                if (hour !in 0..23 || minute !in 0..59) continue
                val mealAt = (day.clone() as Calendar).apply {
                    set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                val key = "meal_done_${dateKey}_$i"
                if (mealAt >= startAt && mealAt <= now && !prefs.getBoolean(key, false)) {
                    eaten += prefs.getInt("meal_cal_$i", defaultCalories[i])
                    edit.putBoolean(key, true)
                }
            }
            day.add(Calendar.DAY_OF_YEAR, 1)
        }
        edit.putInt("eaten_total", eaten).apply()
    }

    private fun saveSettings() {
        val hourly = hourlyInput.text.toString().toIntOrNull()
        val calories = mealInputs.map { it.text.toString().toIntOrNull() }
        val times = timeInputs.map { it.text.toString().trim() }
        if (hourly == null || hourly < 0 || calories.any { it == null || it < 0 }) { toast("熱量請輸入 0 或正整數"); return }
        if (times.any { !it.matches(Regex("([01]?[0-9]|2[0-3]):[0-5][0-9]")) }) { toast("時間格式請使用 08:00") ; return }
        val edit = prefs.edit().putInt("hourly", hourly)
        calories.forEachIndexed { i, value -> edit.putInt("meal_cal_$i", value!!) }
        times.forEachIndexed { i, value -> edit.putString("meal_time_$i", value) }
        edit.apply()
        refreshAndRender()
        toast("設定已儲存")
    }

    private fun numberInput(value: String) = EditText(this).apply {
        setText(value); inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
        textSize = 16f; setSingleLine(true)
    }
    private fun plainInput(value: String) = EditText(this).apply { setText(value); textSize = 16f; setSingleLine(true) }
    private fun text(value: String, size: Int, bold: Boolean, color: Int) = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(5), 0, dp(5))
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun matchWrap() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
